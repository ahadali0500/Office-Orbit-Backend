<?php

namespace App\Http\Controllers\employee\attendance;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class EmployeeAttendanceController extends Controller
{
    public function forgotPassword(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'employee_id' => 'required',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $employee = Employee::where('email', $request->id)->first();
        
        if ($employee) {
            $number=generateUniqueIdentifier();
            $details = [
                'name' => $employee->name,
                'number' => $number
            ];
            $employee->recover_password_opt = $number;
            $employee->save();
            //Mail::to($request->email)->send(new forgotPassword($details));
            return response()->json(['message' => 'Password Recover link sent successfully!'], 200);
        }else{
            return response()->json(['message' => "Invalid credentials"], 401);
        }
    }
}
