<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ManagerAuthController extends Controller
{
    public function register(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'department_id' => 'required',
            'company_token' => 'required',
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:employees',
            'password' => 'required|string|min:8|confirmed',
            'image' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',

        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $imagePath = null;
        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $imageName = time() . '.' . $image->getClientOriginalExtension();
            $imagePath = $image->storeAs('/comapny/logo/', $imageName, 'public');
        }

        $employee = Employee::create([
            'department_id' => $request->department_id,
            'company_token' => $request->company_token,
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'image' => imagePath,
            'join_date'=> date('yyyy-mm-dd')
        ]);

        $token = $employee->createToken('auth-token')->plainTextToken;

        return response()->json(['employee' => $employee, 'token' => $token], 201);
    }
}
