<?php

namespace App\Http\Controllers\company\auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class test extends Controller
{
    //
}
