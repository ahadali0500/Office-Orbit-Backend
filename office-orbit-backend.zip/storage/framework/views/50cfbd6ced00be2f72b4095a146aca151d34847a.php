<!DOCTYPE html>
<html>
<head>
    <title>Recover Password</title>
</head>
<body>
    <h1><?php echo e($details['name']); ?></h1>
    <a href="<?php echo e(env('APP_URL')); ?>/company/recover-password/<?php echo e($details['number']); ?>" ><?php echo e(env('APP_URL')); ?>/company/recover-password/<?php echo e($details['number']); ?></a>
</body>
</html>
<?php /**PATH E:\laragon\www\AttendanceApp\resources\views/mail/company/forgotPassword.blade.php ENDPATH**/ ?>